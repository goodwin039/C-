#include <iostream>
#include <SFML/Network.hpp>
#include <string>

using namespace std;

bool is_port_open(const std::string& address, int port)
{
    return (sf::TcpSocket().connect(address,port) == sf::Socket::Done);
}

int main()
{
    if (is_port_open("localhost",80))
    {
        cout << "OPEN";
    }else{
        cout << "CLOSED";
    }
    return 0;
}
